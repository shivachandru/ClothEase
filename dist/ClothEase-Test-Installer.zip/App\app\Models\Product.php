<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Product extends Model
{
    protected $guarded = ['id'];
    public function variants(): HasMany { return $this->hasMany(ProductVariant::class); }
    public function category() { return $this->belongsTo(Category::class); }
}
