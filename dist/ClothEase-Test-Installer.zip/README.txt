﻿ClothEase Windows Test Installer

1. Extract this ZIP to a folder you can write to.
2. Right-click Install-ClothEase.ps1 and choose Run with PowerShell.
   If Windows blocks it, open PowerShell in this folder and run:
   powershell -NoProfile -ExecutionPolicy Bypass -File .\Install-ClothEase.ps1
3. The installer uses PHP 8.2+ already installed on this PC. XAMPP's PHP is
   detected at C:\xampp\php\php.exe. It must include mbstring, openssl,
   and pdo_sqlite.
4. Start the app from the ClothEase desktop shortcut.

This is a test package, not a production release. It binds the local web server
to 127.0.0.1 only. App files are installed under LocalAppData\Programs\ClothEase;
the environment, database, sessions, logs, and backups stay under
LocalAppData\ClothEase and survive reinstall/update. To reset test data, first
back it up, then remove that data folder yourself.
