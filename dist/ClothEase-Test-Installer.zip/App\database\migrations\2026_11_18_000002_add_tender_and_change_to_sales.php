<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('sales', function (Blueprint $table) {
            $table->decimal('tendered_amount', 12, 2)->default(0)->after('amount_paid');
            $table->decimal('change_due', 12, 2)->default(0)->after('tendered_amount');
        });
    }

    public function down(): void
    {
        Schema::table('sales', function (Blueprint $table) {
            $table->dropColumn(['tendered_amount', 'change_due']);
        });
    }
};
