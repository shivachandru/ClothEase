<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Customer extends Model
{
    protected $guarded=['id'];
    public function sales(){return $this->hasMany(Sale::class);}
    public function payments(){return $this->hasMany(CustomerPayment::class);}
}
